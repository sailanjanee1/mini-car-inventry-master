<?php
include('db.php');
$sql = "UPDATE car_details
SET quantity = 0
WHERE car_id ='".$_POST['carid']."'";
 $exc = mysqli_query($dbh,$sql)or die("Error: " . mysqli_error($dbh));
        if ($exc>0)
        {
            echo "Sold";
        }
        else
        {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }